import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo-form-sku3',
  templateUrl: './demo-form-sku3.component.html',
  styleUrls: ['./demo-form-sku3.component.css']
})
export class DemoFormSku3Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
