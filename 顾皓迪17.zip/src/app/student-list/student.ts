
export const STUDENTS: Student[] = [
    { name: 'zjy1', gender: 1, web: 80, embeded: 90 },
    { name: 'zjy2', gender: 0, web: 90, embeded: 90 },
    { name: 'zjy3', gender: 1, web: 80, embeded: 70 },
    { name: 'zjy4', gender: 0, web: 60, embeded: 80 }
];

export class Student {
    name: string;
    gender: number;
    web: number;
    embeded: number;
}

