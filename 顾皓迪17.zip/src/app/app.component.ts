import { Component } from '@angular/core';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'ch06';
constructor(
  private router: Router,
  private auth:AuthService
){}
indexed(){
  this.auth.logout();
  alert('您已经登出');
  this.router.navigate(['/login']);
}
}
