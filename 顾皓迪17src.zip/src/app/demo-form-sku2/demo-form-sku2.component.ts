import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo-form-sku2',
  templateUrl: './demo-form-sku2.component.html',
  styleUrls: ['./demo-form-sku2.component.css']
})
export class DemoFormSku2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
