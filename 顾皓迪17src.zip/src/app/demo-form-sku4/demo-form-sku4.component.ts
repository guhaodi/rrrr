import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-demo-form-sku4',
  templateUrl: './demo-form-sku4.component.html',
  styleUrls: ['./demo-form-sku4.component.css']
})
export class DemoFormSku4Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
